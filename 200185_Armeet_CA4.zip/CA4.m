clear
%% Inputting
hold off;
choice='y';
disp('NOTE: IF YOU WANT DIFFERENT PLOTS FOR EACH METHOD THEN DE-COMMENT " hold off " at three places');
while choice=='y'
disp("Hello! I'll help you fit a spline in the data points");
fprintf('\n');
mdata=input('First input the data points ,\nexample-if you want (1,2) ,(3,4),(5,6) as the points then enter as:\n1,2 ; 3,4 ; 5,6\n','s'); 
mdata=str2num(mdata);
[n x] = size(mdata);
mest=input('Now enter the data points where you want to estimate the value\n','s');
mest=str2num(mest);
[m y]=size(mest);
meth=input('Choose a method to estimate the value:--\na. Linear spline\nb. Quadratic spline\nc. Natural cubic spline\nd. Not-a-knot cubic spline\ne. Periodic cubic spline\nf. Clamped cubic spine\n','s'); 

%% Different choices

switch meth
    case 'a'
        linear(mdata,n,mest,m);
    case 'b'
        quadr(mdata,n,mest,m);
    case 'c'
        natcube(mdata,n,mest,m);
    case 'd'
       notcube(mdata,n,mest,m);
    case 'e'
        pericube(mdata,n,mest,m);
    case 'f'
       clacube(mdata,n,mest,m);
end
choice= input("Do you want me to estimate the values using another method or for another set of data points?\nEnter y/n:",'s');
end
%% fxn to get the suitable interval where the given x value lies 
function i=retindi(data,mdata,n)
for i=1:n-1
    if data<=mdata(i+1) 
        return
    end
end
end
%% linear spline
function linear(mdata,n,mest,m)
for j=1:m
   i=retindi(mest(j),mdata(:,1),n);
   est(j)=(   (mest(j)-mdata(i,1))*mdata(i+1,2)-(mest(j)-mdata(i+1,1))*mdata(i,2))/(mdata(i+1,1)-mdata(i,1));
end
disp("The estimated values corresponding to the given points are");
fprintf("%f   %f\n",[mest,est']');
for i=1:n-1
   fplot(@(x)((x-mdata(i,1)).*mdata(i+1,2)-(x-mdata(i+1,1)).*mdata(i,2))./(mdata(i+1,1)-mdata(i,1)),[mdata(i,1) mdata(i+1,1)],'LineWidth',1,'color','c');
   hold on;    
end
plot(mest',est,"co")
xlabel("x");
ylabel("y");
% legend("Linear spline");
% hold off;
end

%% quadratic spline
function quadr(mdata,n,mest,m)
sig(1)=(mdata(2,2)-mdata(1,2))/(mdata(2,1)-mdata(1,1));
for i=1:n-1
    h(i)=mdata(i+1,1)-mdata(i,1);
    g(i)=(mdata(i+1,2)-mdata(i,2))/h(i);
    sig(i+1)=2*g(i)-sig(i);
    c(i)=mdata(i+1,2)-(sig(i+1)*h(i))/2;
    
    fplot(@(x)( (sig(i+1)./(2.*h(i))).*(x-mdata(i,1)).^2-(sig(i)./(2.*h(i))).*(x-mdata(i+1,1)).^2 +c(i)),[mdata(i,1) mdata(i+1,1)],'LineWidth',1.1,'color','g')
    hold on; 
end
  
for j=1:m
   i=retindi(mest(j),mdata(:,1),n);
   est(j)=(sig(i+1)*(mest(j)-mdata(i,1))^2-sig(i)*(mest(j)-mdata(i+1,1))^2)/(2*h(i)) +c(i);

end
disp("The estimated values corresponding to the given points are");
fprintf("%f  %f\n",[mest,est']');
plot(mest',est,"go")
xlabel("x");
ylabel("y");
% legend("Quadratic spline");
% hold off;

end

%% general spline
function [genmat,h,g]=genspline(mdata,n)
    genmat=zeros(n-2,n);
    h(1)=mdata(2,1)-mdata(1,1);
    g(1)=(mdata(2,2)-mdata(1,2))/h(1);
 for i=2 : n-1
    h(i)=mdata(i+1,1)-mdata(i,1);
    g(i)=(mdata(i+1,2)-mdata(i,2))/h(i);
    genmat(i-1,i-1)=h(i-1);
    genmat(i-1,i)=2*(h(i-1)+h(i));
    genmat(i-1,i+1)=h(i);
    genmat(i-1,n+1)=6*(g(i)-g(i-1));
 end
end
%% Plotting the spline and printing the estimate values
function plotnvalues(sigma,hi,mdata,mest,n,m,str,clr)

c=mdata(2:n,2)./hi' -(sigma(2:n,1).*hi')/6;
d=mdata(1:n-1,2)./hi' -(sigma(1:n-1,1).*hi')/6;

for i=1:n-1
  fplot(@(x)( (sigma(i+1)./(6.*hi(i))).*(x-mdata(i,1)).^3-(sigma(i)./(6.*hi(i))).*(x-mdata(i+1,1)).^3 +c(i).*(x-mdata(i,1))-d(i).*(x-mdata(i+1,1))),[mdata(i,1) mdata(i+1,1)],'LineWidth',1.2,'color',clr)
  hold on; 

end

for j=1:m
   i=retindi(mest(j),mdata(:,1),n);
   est(j)=(sigma(i+1)./(6.*hi(i))).*(mest(j)-mdata(i,1)).^3-(sigma(i)./(6.*hi(i))).*(mest(j)-mdata(i+1,1)).^3 +c(i).*(mest(j)-mdata(i,1))-d(i).*(mest(j)-mdata(i+1,1));

end
disp("The estimated values corresponding to the given points are");
fprintf("%f   %f\n",[mest,est']');
plot(mest',est,clr+"o")
xlabel("x");
ylabel("y");
%legend(str);
% hold off;
end
%% natural cubic spline
function natcube(mdata,n,mest,m)
[genmat,h,g]=genspline(mdata,n);
natmat=genmat(:,2:n-1);
b=genmat(:,n+1);
x=inv(natmat)*b;
sig(1,1)=0;
sig(2:n-1,1)=x;
sig(n,1)=0;
plotnvalues(sig,h,mdata,mest,n,m,'Natural cubic spline','b');

end
%% Not-a-knot spline 
function notcube(mdata,n,mest,m)
[genmat,h,g]=genspline(mdata,n);
natmat=zeros(n);
natmat(1,1:3)=[h(2),-(h(1)+h(2)),h(1)];
natmat(n,n-2:n)=[h(n-1),-(h(n-2)+h(n-1)),h(n-2)];
natmat(2:n-1,1:n)= genmat(:,1:n);
b(1,1)=0;
b(2:n-1,1)=genmat(:,n+1);
b(n,1)=0;
x=inv(natmat)*b;
plotnvalues(x,h,mdata,mest,n,m,'Not-a-Knot cubic spline','r');
end

%% periodic spline
function pericube(mdata,n,mest,m)

[genmat,h,g]=genspline(mdata,n);
natmat=zeros(n);
natmat(1,1)=1;
natmat(1,n)=-1;
natmat(n,1:2)=[-(h(1)+h(n-1))/3, -h(1)/6];
natmat(n,n-1)= -h(n-2)/6;

natmat(2:n-1,1:n)= genmat(:,1:n);
b(1,1)=0;
b(2:n-1,1)=genmat(:,n+1);
b(n,1)=g(n-1)-g(1)
x=inv(natmat)*b;
plotnvalues(x,h,mdata,mest,n,m,'Periodic cubic spline','y');
end


%% clamped spline
function clacube(mdata,n,mest,m)
slop=input('Enter the value of slopes at the beginning and end nodes\n example-if they are 2.4 and 5 ,then enter as:   2.4;5.\nNow enter: ','s');
slop=str2num(slop);
[genmat,h,g]=genspline(mdata,n);
natmat=zeros(n);
natmat(1,1:2)=[-h(1)/3,-h(1)/6];
natmat(n,n-1:n)=[h(n-1)/6,h(n-1)/3];
natmat(2:n-1,1:n)= genmat(:,1:n);
b(1,1)=slop(1)-g(1);
b(2:n-1,1)=genmat(:,n+1);
b(n,1)=slop(2)-g(n-1);
x=inv(natmat)*b;
plotnvalues(x,h,mdata,mest,n,m,'Clamped cubic spline','m');
end
