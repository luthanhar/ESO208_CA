clear
%% Inputting

choice='y';
while choice=='y'

disp("Hello! I'll help you to solve a system of linear equations Ax=b");
fprintf('\n');
n=input('First enter the number of equations you want to solve \nn=');
matrix=input('Now enter the augmented matrix\n example- if there are 2 equations- 2x+y=8, 3x=9 enter as:\n2 1 8 ; 3 0 9 or 2,1,8 ; 3,0,9\nAugmented matrix:\n','s');
matrix=str2num(matrix);
display(matrix);
meth=input('Choose a method to find the solution:--\na. Gauss elimination (GE; without pivoting)\nb. GE (with pivoting)\nc. GE (with scaling and pivoting)\nd. LU decomposition by using GE (without pivoting)\ne. LU decomposition by using GE (with pivoting)\nf. LU decomposition by using Crout method (without pivoting)\ng. Cholesky decomposition (for symmetric positive definite matrix)\nMethod: ','s');

%% Different choices

switch meth
    case 'a'
        gausseli(matrix,n);
    case 'b'
        gausselip(matrix,n);
    case 'c'
        gausselips(matrix,n);
    case 'd'
       loude(matrix,n);
    case 'e'
        loudep(matrix,n);
    case 'f'
        crout(matrix,n);
    case 'g'
       choksy(matrix,n);
end


choice= input("Do you want me to find solution to another set of equations?\nEnter y/n:",'s');
end



%% Forward substitution
function x=forsubs(n,matrix)
x=zeros(n,1);
x(1)= matrix(1,n+1)/matrix(1,1);

 for i=2:n
     sum=0;
     for j=1:i-1
         sum=sum+matrix(i,j)*x(j);
     end
     x(i)=(matrix(i,n+1)-sum)/matrix(i,i);
     
     
 end

end










%% Back substitution
function x=backsubs(n,matrix)
x=zeros(n,1);
x(n)= matrix(n,n+1)/matrix(n,n);

 for i=n-1:-1: 1
     sum=0;
     for j=i+1:n
         sum=sum+matrix(i,j)*x(j);
     end
     x(i)=(matrix(i,n+1)-sum)/matrix(i,i);
     
 end

end

%% Gauss elimination without pivoting
function  gausseli(matrix,n)

for k=1:n-1
     if matrix(k,k)==0 
        fprintf("Pivoting is required to find the solution, Select another set of equation or method:\n");
        x='nada';
    return 
     end
    
    for i=k+1:n
           
    l=matrix(i,k)/matrix(k,k);
    
   matrix(i,:)=matrix(i,:)-l.*matrix(k,:);
      
    
    end
end

x=backsubs(n,matrix);

 
format long;
display(x);
fprintf("The elements of the upper triangular matrix are :\n");
disp(matrix(:,[1:n] ) );
end

%% Gauss elimination with pivoting
function  gausselip(matrix,n)
Iarm= eye(n);
for k=1:n-1
    
    [maxi ,indi]= max(abs(matrix([k:n],k)));
    indi=indi+k-1;
    
   matrix([k indi],:)= matrix([indi k],:);
   Iarm([k indi],:)=Iarm([indi k],:);
    
    for i=k+1:n    
        
    l=matrix(i,k)/matrix(k,k);
    
   matrix(i,:)=matrix(i,:)-l.*matrix(k,:);
     
    end
end

x=backsubs(n,matrix);

 
format long;
display(x);
fprintf("The elements of the upper triangular matrix are :\n");
disp(matrix(:,[1:n] ) );
fprintf("The permuataion matrix is:\n");
disp(Iarm);
end

%% Gauss elimination with pivoting+scaling
function  gausselips(matrix,n)
Iarm= eye(n);
taxi=zeros(n,1);

for k=1:n-1
    
    for(i=k:n)
        [r,q]=max(abs(matrix(i,[1:n])));
     
    taxi(i)=matrix(i,k)/matrix(i,q);
    end
    
   
    
    [maxi ,indi]= max(abs(taxi(k:n)));
   
    indi=indi+k-1;
    
   matrix([k ,indi],:)= matrix([indi, k],:);
   
   Iarm([k ,indi],:)=Iarm([indi, k],:);
    
    for i=k+1:n    
        
    l=matrix(i,k)/matrix(k,k);
    
   matrix(i,:)=matrix(i,:)-l.*matrix(k,:);
   
     
    end
end

x=backsubs(n,matrix);

 
format long;
display(x);
fprintf("The elements of the upper triangular matrix are :\n");
disp(matrix(:,[1:n] ) );
fprintf("The permuataion matrix is:\n");
disp(Iarm);
end

%% lu decomposition without pivoting
function  loude(matrix,n)
b=matrix(:,n+1);
matrixl=eye(n);
for k=1:n-1
     if matrix(k,k)==0 
        fprintf("Pivoting is required to find the solution, Select another set of equation or method:\n")
    return 
     end
    
    for i=k+1:n
           
    l=matrix(i,k)/matrix(k,k);
    
   matrix(i,:)=matrix(i,:)-l.*matrix(k,:);
   
   matrixl(i,k)=l;
  
      
    
    end
    
end
fprintf("The lower triangular matrix is:\nL:\n");
disp(matrixl);
fprintf("The upper triangular matrix is:\nU:\n");
disp(matrix(:,[1:n]));
matrixl(:,n+1)=b;
     y=forsubs(n,matrixl);
     matrix(:,n+1)=y;
   x=backsubs(n,matrix);
format long;
display(x);



end
%% lu decomposition with pivoting
function  loudep(matrix,n)
b=matrix(:,n+1);
matrixl=eye(n);
Iarm=eye(n);
P=eye(n);
Q=eye(n);
matrixltemp=eye(n);
for k=1:n-1
    [maxi ,indi]= max(abs(matrix([k:n],k)));
    
    indi=indi+k-1;
    
    
     if(k>1)
      P([k indi],:)=P([indi k],:);
           Q=P*Q;
       matrixl=matrixl*matrixltemp*P;
       matrixltemp=eye(n);
       P=eye(n);
       
   end
    matrix([k indi],:)= matrix([indi k],:);
    Iarm([k indi],:)=Iarm([indi k],:);

  
   
    for i=k+1:n
           
    l=matrix(i,k)/matrix(k,k);
    
   matrix(i,:)=matrix(i,:)-l.*matrix(k,:);
   
   matrixltemp(i,k)=l;
   
   
    
    end
    if(k==n-1) 
       matrixl=matrixl*matrixltemp; 
    end
    
    
end

matrixl=Q*matrixl;
format long;
fprintf("The lower triangular matrix is:\nL:\n");
disp(matrixl);
fprintf("The upper triangular matrix is:\nU:\n");
disp(matrix(:,[1:n]));
fprintf("The permuataion matrix is:\n");
disp(Iarm);
b=Iarm*b;

matrixl(:,n+1)=b;
     y=forsubs(n,matrixl);
     matrix(:,n+1)=y;
   x=backsubs(n,matrix);
format long
display(x);




end


%% crout's method

function crout(matrix,n)
u=eye(n);

l(1,1)=matrix(1,1);
for j=2:n
    
   l(j,1)=matrix(j,1);
   u(1,j)=matrix(1,j)/l(1,1);
    
    
end

for k=2:n
   
  for i=k:n
      sum=0;sum1=0;
      for z=1: k-1
          sum= sum+l(i,z)*u(z,k);
          sum1=sum1+l(k,z)*u(z,i);
      end
     l(i,k)=matrix(i,k)-sum; 
     if(i>k)
        u(k,i)=(matrix(k,i)-sum1)/l(k,k);  
     end
          
  end
    
end
format long;
fprintf("The lower triangular matrix is:\nL:\n");
disp(l);
fprintf("The upper triangular matrix is:\nU:\n");
disp(u);
l(:,n+1)=matrix(:,n+1);
     y=forsubs(n,l);
     u(:,n+1)=y;
   x=backsubs(n,u);

display(x);



end


%% Choksy algorithm
function choksy(matrix,n)

l(1,1)=sqrt(matrix(1,1));
for j=2:n
    l(j,1)=matrix(j,1)/l(1,1);
end


for k=2:n
    
    sum=0; 
    for z=1:k-1
    sum=sum+l(k,z)^2;    
    
    end
    
    l(k,k)=sqrt(matrix(k,k)-sum);
      
   
    for i= k+1:n
     sum1=0;
      for z=1:k-1
    sum1=sum1+l(k,z)*l(i,z);    
      end
       l(i,k)=(matrix(i,k)-sum1)/l(k,k);
     
    
    end

end
u=l';
fprintf("The lower triangular matrix is:\nL:\n");
format long;
disp(l);
l(:,n+1)=matrix(:,n+1);
     y=forsubs(n,l);
     u(:,n+1)=y;
   x=backsubs(n,u);
format longG;
display(x);

end
