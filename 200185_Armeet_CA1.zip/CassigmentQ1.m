clear
%% Inputting

choice='y';
while choice=='y'

disp("Hello! I'll help you to find the roots of non-linear equations");
fprintf('\n');
str=input('First enter a non linear equation to begin with! \nexample- 3*x^2+5*x \nf(x)=','s');
eq = str2func(['@(x) ' str]);
meth=input("Choose a method to find it's root:--\na. Bisection\nb. False-position \nc. Modified false-position \nd. Newton-Raphson\ne. Secant \n(example: enter the letter 'a' for bisection)\nMethod: ",'s');
while ~(meth=='a' || meth =='b' || meth =='c'||meth =='d' ||meth =='e')
    meth=input("Please enter a value between 'a' and 'e'\n",'s');
end
if (meth=='d')
    nr=input("Enter an initial guess value : ");
   
else
    xo=input("Enter 2 initial guess values of x that lie on opposite side of root in ascending order(xo<x1) : \nxo: ");
    x1=input("x1: ");
    while (eq(xo)*eq(x1))>0 && meth~='e'
        disp("The entered values do not bracket the root. Please enter another set of values: ");
        xo=input("xo :");
        x1=input("x1 :");
    end 
end

if meth=='d'
    if eq(nr)==0
    plot(nr,eq(nr),"rs")
    title("Plot of f x( ) vs x");
    xlabel('x');
    ylabel('f(x)');
    fprintf("Relative approximate error makes no sense since the guess value is the actual root\nRoots of equation= %f",nr)
    choice=input("\nDo you want to find the root for another equation? Enter y/n :",'s');
    continue;
    end
elseif eq(xo)*eq(x1)==0
    if(eq(xo)==0) 
        num=xo;
    else
        num=x1;
    end
    plot([xo,x1],[eq(xo),eq(x1)],"ro")
    title("Plot of f x( ) vs x (See red circles)");
    xlabel('x');
    ylabel('f(x)');
    fprintf("Relative approximate error makes no sense since the guess value is the actual root\nRoot of equation= %f",num)
    choice=input("\nDo you want to find the root for another equation? Enter y/n :",'s');
    continue
end
mi=input("Enter maximum iterations: ");
mae=input("Enter maximum approximate relative error\n(example- Enter 0.2 if error is 0.2%)\nError: ");
syms x;
d=str2func("@(x) "+ char(diff(eq(x))));
%% Different choices

switch meth
    case 'a'
        [xr,ae]=bisection(xo,x1,eq,mae,mi);
    case 'b'
        [xr,ae]=false(xo,x1,eq,mae,mi);
    case 'c'
        [xr,ae]=mfalse(xo,x1,eq,mae,mi);
    case 'd'
       [xr,ae]=newton(nr,eq,mae,mi,d);
    case 'e'
        [xr,ae]=secant(xo,x1,eq,mae,mi);
end

%% Output
if(meth=='d' || meth=='e')
    no=1;
    nol=1;
else
    no=2;
    nol=2;
    ae(1)="NA";
end
x2=zeros(length(xr),1);
for i=1:length(xr)
x2(i)=eq(xr(i));
end

minx=min(xr);
maxx=max(xr);

disp("Values of xi for each iteration i: ");
disp(xr);
disp("Values of approximate % error for each iteration: ");
disp(ae);
fprintf("The approximate root of the equation is: ");
disp(xr(length(xr)));
xp=linspace(minx-1,maxx+1,mi);
figure(1)
S = vectorize(str);
eq2=str2func(['@(x) ' S]);
plot(xp,eq2(xp),"b");
    title("Plot of f(x) vs x");
    xlabel('x');
    ylabel('f(x)');
   hold on
  plot(xr,x2,"ro")   
    
hold off
   
figure(2)
plot(no:length(ae),ae([nol:length(ae)]),"b")
    title("Plot of Approximate relative % error vs Iteration number");
    xlabel('Iterations');
    ylabel('Percent relative error'); 
    hold on
plot(no:length(ae),ae([nol:length(ae)]),"ro")
hold off    
 

choice=input("\nDo you want to find the root for another equation? Enter y/n :",'s');end




%% Code for the function to calculate root by bisection method
function [xr,ae]=bisection(xl,xu,f,mae,mi)

for i=1:mi
    xr(i)=(xl+xu)/2;
    
if(i>1)
    ae(i)= abs((xr(i)-xr(i-1))*100/xr(i));
    if(ae(i)<=mae) 
        return
    end
end
   if(f(xr(i))==0) 
 
    return
   end
    if(f(xl)*f(xr(i))<0)
        xu=xr(i);
    else
        xl=xr(i);
    end
end 
end
%% Code for the function to calculate root by false position

function [xr,ae]=false(xl,xu,f,mae,mi)
for i=1:mi
    xr(i)=(xu*f(xl)-xl*f(xu))/(f(xl)-f(xu)) ;
    
if(i>1)
    ae(i)= abs((xr(i)-xr(i-1))*100/xr(i));
    if(ae(i)<=mae) 
        return
    end
end

if(f(xr(i))==0)  
    return
end
   
    if(f(xl)*f(xr(i))<0)
        xu=xr(i);
    else
        xl=xr(i);
    end
end 
end
%% Code for the function to calculate root by modified false position

function [xr,ae]=mfalse(xl,xu,f,mae,mi)
iterl=0;
iteru=0;
 xr(1)=(xu*f(xl)-xl*f(xu))/(f(xl)-f(xu)) ;
for i=1:mi
  
if(i>1)
    ae(i)= abs((xr(i)-xr(i-1))*100/xr(i));
    if(i==mi)
        return
    end
    if(ae(i)<=mae) 
        return
    end
end

if(f(xr(i))==0)  
    return
end
   
    if(f(xl)*f(xr(i))<0)
        xu=xr(i);
        iteru=0;
        iterl=iterl+1;
        if(iterl>1)
            xr(i+1)=(xu*(f(xl)/2^(iterl-1))-xl*f(xu))/( f(xl)/2^(iterl-1)-f(xu));
        else 
            xr(i+1)=(xu*f(xl)-xl*f(xu))/(f(xl)-f(xu));
        end
        
        
    else
        xl=xr(i);
        iterl=0;
        iteru=iteru+1;
        if(iteru>1)
            xr(i+1)=(xu*f(xl)-xl*(f(xu)/2^(iteru-1)))/( f(xl)-(f(xu)/2^(iteru-1)));
        else 
            xr(i+1)=(xu*f(xl)-xl*f(xu))/(f(xl)-f(xu));
            
        end
    end
end 
end


%% Code for the function to calculate root by Newton Raphson
function [xr,ae]=newton(nr,f,mae,mi,d)
xr(1)=nr-f(nr)/d(nr);
ae(1)= abs((xr(1)-nr)*100/xr(1));
if( ae(1)<=mae || f(xr(1))==0 )
    return
end

for i=1:mi-1
    
    xr(i+1)= xr(i)-f(xr(i))/d(xr(i));   
    
    ae(i+1)= abs((xr(i+1)-xr(i))*100/xr(i+1));
    if(ae(i+1)<=mae)
        return
    end


if(f(xr(i+1))==0)  
    return
end
   
   
end 
end

%% Code for the function to calculate root by secant method
function [xr,ae]=secant(xl,xu,f,mae,mi)
 xr(1)=(xu*f(xl)-xl*f(xu))/(f(xl)-f(xu)) ;
 ae(1)= abs((xr(1)-xu)*100/xr(1));
 if( ae(1)<=mae || f(xr(1))==0 )
    return
end
xl=xu;
xu=xr(1);

for i=1:mi-1
    xr(i+1)=(xu*f(xl)-xl*f(xu))/(f(xl)-f(xu)) ;
    ae(i+1)= abs((xr(i+1)-xr(i))*100/xr(i+1));
    if(ae(i+1)<=mae) 
        return
   
end

if(f(xr(i+1))==0)  
    return
end
   
xl=xu;
xu=xr(i+1);
   
end 
end





