clear
%% Inputting

choice='y';
while choice=='y'

disp("Hello! I'll help you to find the roots of a polynomial");
fprintf('\n');
str=input('First enter a polynomial to begin with! \nexample- 3*x^2+5*x \nf(x)=','s');
eq = str2func(['@(x) ' str]);
meth=input("Choose a method to find it's root:--\na. Muller\nb. Bairstow \n(example: enter the letter 'a' for Muller)\nMethod: ",'s');
while ~(meth=='a' || meth =='b' )
    meth=input("Please enter a value 'a' or 'b'\n",'s');
end

if(meth=='a')
    xo=input("Enter 3 initial guess values of x in ascending order(xo<x1<x2) : \nxo: ");
    x1=input("x1: ");
    x2=input("x2: ");
else
    r=input("Enter 2 guess values : \nr:");
    s=input("s:");
    
    
end
mi=input("Enter maximum iterations: ");
mae=input("Enter maximum approximate relative error\n(example- Enter 0.2 if error is 0.2%)\nError: ");
S = vectorize(str);
eq2=str2func(['@(x) ' S]);

%% Different choices

switch meth
    case 'a'
        [xr,ae]=muller(xo,x1,x2,eq,mae,mi);
    case 'b'
        bairstow(r,s,eq,mae,mi,eq2);
end 
%% Output of muller method
if meth=='a'
x2=zeros(length(xr),1);
for i=1:length(xr)
x2(i)=eq(xr(i));
end
minx=min(xr);
maxx=max(xr);
format long g
disp("Values of xi for each iteration i: ");
disp(xr([4:length(xr)]));
disp("Values of approximate % error for each iteration: ");
disp(ae);
fprintf("The approximate root of the equation is: ");
disp(xr(length(xr)));
xp=linspace(minx,maxx,mi);
figure(1)

plot(xp,eq2(xp),"b");
    title("Plot of f(x) vs x");
    xlabel('x');
    ylabel('f(x)');
   hold on
  plot(xr,x2,"ro")   
    
hold off


figure(2)
plot(1:length(ae),ae([1:length(ae)]),"b")
    title("Plot of Approximate relative % error vs Iteration number");
    xlabel('Iterations');
    ylabel('Percent relative error'); 
    hold on
plot(1:length(ae),ae([1:length(ae)]),"ro")
hold off 
end
choice=input("\nDo you want to find the root for another equation? Enter y/n :",'s'); 
end

%%Muller method code
function [xr,ae]=muller(xo,x1,x2,f,mae,mi)
xr(1)=xo;
xr(2)=x1;
xr(3)=x2;
for i=0:mi-1 
h1=xr(2+i)-xr(1+i);
h2=xr(3+i)-xr(2+i);
d1= (f(xr(2+i))-f(xr(1+i)))/h1;
d2=(f(xr(3+i))-f(xr(2+i)))/h2;
a=(d2-d1)/(xr(3+i)-xr(1+i));
b=a*h2+d2;
c=f(xr(3+i));
if(b<0)
v=(-2*c)/(b-sqrt(b^2-4*a*c));
else
v=(-2*c)/(b+sqrt(b^2-4*a*c));
end
xr(4+i)=xr(3+i)+v;
ae(i+1)= abs(((xr(i+4)-xr(i+3))*100)/xr(i+4));
if(  ae(i+1)<=mae || f(xr(i+4))==0) 
        return ;
end
   
end
end


%% Bairstow method
function bairstow(r,s,f,mae,mi,eq2)
kj=1;
syms x;
a=coeffs(f(x),'All');
a=eval(a);
b(1)=a(1);
c(1)=b(1);
roots=0;
if(length(a)-1)>=3
    check='ok';
elseif (length(a)-1)==2
    check='q';
else
    check='l'; 
    xr(1)=-a(2)/a(1);
end

while(check=='ok')
for k=1 :mi
    b(2)=a(2)+r*b(1);
    c(2)=b(2)+r*c(1);
for i= 1:(length(a)-2)
    
    b(2+i)=a(2+i)+r*b(1+i)+s*b(i);
    c(2+i)=b(2+i)+r*c(1+i)+s*c(i);
end
j=c(length(c)-1)*c(length(c)-3)-(c(length(c)-2))^2;
del(1)=(b(length(b)-1)*c(length(c)-2)-b(length(b))*c(length(c)-3))/j;
del(2)=(b(length(b))*c(length(c)-2)-b(length(b)-1)*c(length(c)-1))/j;

r=r+del(1);
s=s+del(2);
ae(kj,1)=abs(del(1)*100/r);
ae(kj,2)=abs(del(2)*100/s);
if( ae(kj,1)<=mae && ae(kj,2)<=mae) || (b(length(b))==0 && b(length(b)-1)==0)
    break;
end
 kj=kj+1;
end

xr(roots+1)=(r-sqrt(r^2+4*s))/2;
xr(roots+2)=(r+sqrt(r^2+4*s))/2;
roots=roots+2;
if(length(a)-1-roots)>=3
    check='ok';
elseif (length(a)-1-roots)==2
    check='q';
    a=b([1:(length(b)-2)]);
    break;
else
    check='l';
    xr(roots+1)=-b(length(b)-2)/b(length(b)-3); 
    roots=roots+1;
    break;
end
a=b([1:(length(b)-2)]);
b=a;
c=a;

end

if(check=='q')

xr(roots+1)= (-a(2)+sqrt(a(2)^2-4*a(1)*a(3)))/(2*a(1));
xr(roots+2)= (-a(2)-sqrt(a(2)^2-4*a(1)*a(3)))/(2*a(1));
roots=roots+2;
end
format long g
disp("Values of approximate % error in r and s ");
disp(ae);
format long g
fprintf("The approximate roots of the polynomial equations are : ");
display(xr);
xp=linspace(-6,6,100);
figure(1)
plot(xp,eq2(xp),"b")
    title("Plot of f(x) vs x");
    xlabel('x');
    ylabel('f(x)');
end