clear
%% Inputting

choice='y';
while choice=='y'

disp("Hello! I'll help you find eigen values of the matrix of your choice");
fprintf('\n');
matrix=input('First enter a square matrix\nexample- if the matrix is:\n3 2 1\n4 3 4\n4 6 9 \nthen enter:\n3 2 1;4 3 4;4 6 9 \nmatrix:\n','s');
matrix=str2num(matrix);
[n n]=size(matrix);
mi=input("Enter maximum iterations: ");
mae=input("Enter maximum approximate relative error\n(example- Enter 0.2 if error is 0.2%)\nError: ");
display(matrix);
meth=input('Choose a method to find the solution:--\na. Direct power method (to find the eigenvalue having the maximum magnitude and the corresponding eigenvector) \nb. Inverse power method (to find the eigenvalue having the minimum magnitude and the corresponding eigenvector) \nc. Shifted-power method (to find intermediate eigenvalues [based on Gershgorin disc] and corresponding eigenvectors) \nd. QR method (to find all eigenvalues of a matrix; write your own program for GramSchmidt process)\nMethod:','s');

%% Different choices

switch meth
    case 'a'
        direct(matrix,n,mi,mae);
    case 'b'
        inverse(matrix,n,mi,mae);
    case 'c'
        shift(matrix,n,mi,mae);
    case 'd'
       qrmeth(matrix,n,mi,mae);
end


choice= input("Do you want me to find eigen values for another matrix?\nEnter y/n:",'s');
end



%% common function for power methods
function [i,scale1,q2]=common(matrix,n,mi,mae)
q2=ones(n,1);
scale0= 1;
for i=1:mi   
quesar=q2/scale0;
q2= matrix*quesar;
[j indi]= max(abs(q2));
scale1= q2(indi);
er= abs((scale1-scale0)*100/scale1);
format long
if(er<=mae && i>1)
return;
end
scale0=scale1; 
end
end

%% printing for power methods
function printi(i,evector,evalue)
evector=evector/norm(evector);
fprintf("The eigen value is :%f \nThe number of iterations is: %d \nThe normalised eigen vector is : \n",evalue,i); 
disp(evector);
end


%% direct power method
function direct(matrix,n,mi,mae)

[i,scale1,quesar]=common(matrix,n,mi,mae);
% if(q2==matrix*quesar) 
% display("display");
% end
printi(i,quesar,scale1);

end

%% inverse power method
function inverse(matrix,n,mi,mae)
inarm= inv(matrix);
[i,scale1,quesar]=common(inarm,n,mi,mae);
evalue= 1/(scale1);
printi(i,quesar,evalue);
end

%% shifted power method
function shift(matrix,n,mi,mae)
shift=input("Please enter the shifting scalar : ");
matrix=matrix-shift*eye(n);
inarm= inv(matrix);
[i,scale1,quesar]=common(inarm,n,mi,mae);
display(shift);
evalue= (1/scale1)+shift;
printi(i,quesar,evalue);
end

%% Grahm schimdt orthogonalisation

function [Q R]= grammer(A,n)
for i=1:n
    sum=0;
    for j=1:i-1
        sum =sum+ (A(:,i)'*Q(:,j))*Q(:,j);
    end
    temp=(A(:,i)-sum);
    Q(:,i)=temp/norm(temp);
    R(i,:)=Q(:,i)'*A;
end

end

%% printing the eigen values for QR method
function printeig(A,n,i)
for j=1:n
    fprintf("The eigen value number %d is : %f\n",j,A(j,j));
end

fprintf("The number of iterations is :%d\n",i);


end
%% QR METHOD FUNCTION
function qrmeth(matrix,n,mi,mae)

for i=1:mi
  [Q R]= grammer(matrix,n);
  A=R*Q;
  for j=1:n
      er(j)=abs((A(j,j)-matrix(j,j))*100/A(j,j));
  end
 if(max(er)<=mae)
     printeig(A,n,i);
     return
 end
 
 matrix=A;
 
 
 
end
  
 printeig(A,n,i);   
    
end

